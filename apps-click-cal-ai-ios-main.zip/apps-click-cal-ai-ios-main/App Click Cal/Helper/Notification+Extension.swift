//
//  Notification+Extension.swift
//  App Click Cal
//
//  Created by Pushpendra on 24/05/25.
//

import Foundation

extension Notification.Name {
    static let didCapturePhoto = Notification.Name("didCapturePhoto")
}
